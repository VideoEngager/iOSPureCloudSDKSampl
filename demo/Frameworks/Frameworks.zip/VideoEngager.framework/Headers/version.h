//
//  version.h
//  VideoEngager
//
//  Created by Bozhko Terziev on 9/28/17.
//  Copyright © 2017 VideoEngager. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VideoEngager.
FOUNDATION_EXPORT double VideoEngagerVersionNumber;

//! Project version string for VideoEngager.
FOUNDATION_EXPORT const unsigned char VideoEngagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VideoEngager/PublicHeader.h>


